<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'location', 'phone'];

    public function stockReceipts()
    {
        return $this->hasMany(StockReceipt::class);
    }
}