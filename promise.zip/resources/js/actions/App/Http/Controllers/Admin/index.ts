import DashboardController from './DashboardController'
import ProductController from './ProductController'
import CategoryController from './CategoryController'
import SupplierController from './SupplierController'
import SaleController from './SaleController'
import InventoryController from './InventoryController'

const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    ProductController: Object.assign(ProductController, ProductController),
    CategoryController: Object.assign(CategoryController, CategoryController),
    SupplierController: Object.assign(SupplierController, SupplierController),
    SaleController: Object.assign(SaleController, SaleController),
    InventoryController: Object.assign(InventoryController, InventoryController),
}

export default Admin