import ProductController from './ProductController'
import CategoryController from './CategoryController'

const Api = {
    ProductController: Object.assign(ProductController, ProductController),
    CategoryController: Object.assign(CategoryController, CategoryController),
}

export default Api