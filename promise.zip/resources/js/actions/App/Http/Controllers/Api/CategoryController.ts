import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::index
* @see app/Http/Controllers/Api/CategoryController.php:14
* @route '/api/categories'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
export const dropdown = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dropdown.url(options),
    method: 'get',
})

dropdown.definition = {
    methods: ["get","head"],
    url: '/api/categories/dropdown',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
dropdown.url = (options?: RouteQueryOptions) => {
    return dropdown.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
dropdown.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dropdown.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
dropdown.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dropdown.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
const dropdownForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dropdown.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
dropdownForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dropdown.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::dropdown
* @see app/Http/Controllers/Api/CategoryController.php:60
* @route '/api/categories/dropdown'
*/
dropdownForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dropdown.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dropdown.form = dropdownForm

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
export const withCounts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withCounts.url(options),
    method: 'get',
})

withCounts.definition = {
    methods: ["get","head"],
    url: '/api/categories/with-counts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
withCounts.url = (options?: RouteQueryOptions) => {
    return withCounts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
withCounts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: withCounts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
withCounts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: withCounts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
const withCountsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withCounts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
withCountsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withCounts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::withCounts
* @see app/Http/Controllers/Api/CategoryController.php:74
* @route '/api/categories/with-counts'
*/
withCountsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: withCounts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

withCounts.form = withCountsForm

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
export const show = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/categories/{category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
show.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { category: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: typeof args.category === 'object'
        ? args.category.id
        : args.category,
    }

    return show.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
show.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
show.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
const showForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
showForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\CategoryController::show
* @see app/Http/Controllers/Api/CategoryController.php:47
* @route '/api/categories/{category}'
*/
showForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const CategoryController = { index, dropdown, withCounts, show }

export default CategoryController