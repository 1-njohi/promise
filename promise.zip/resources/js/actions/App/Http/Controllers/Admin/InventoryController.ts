import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/add',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/inventory',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
export const receipts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipts.url(options),
    method: 'get',
})

receipts.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/receipts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receipts.url = (options?: RouteQueryOptions) => {
    return receipts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receipts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receipts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
const receiptsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receiptsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receiptsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

receipts.form = receiptsForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::destroyReceipt
* @see app/Http/Controllers/Admin/InventoryController.php:142
* @route '/admin/inventory/receipts/{receipt}'
*/
export const destroyReceipt = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyReceipt.url(args, options),
    method: 'delete',
})

destroyReceipt.definition = {
    methods: ["delete"],
    url: '/admin/inventory/receipts/{receipt}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::destroyReceipt
* @see app/Http/Controllers/Admin/InventoryController.php:142
* @route '/admin/inventory/receipts/{receipt}'
*/
destroyReceipt.url = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { receipt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { receipt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            receipt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        receipt: typeof args.receipt === 'object'
        ? args.receipt.id
        : args.receipt,
    }

    return destroyReceipt.definition.url
            .replace('{receipt}', parsedArgs.receipt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::destroyReceipt
* @see app/Http/Controllers/Admin/InventoryController.php:142
* @route '/admin/inventory/receipts/{receipt}'
*/
destroyReceipt.delete = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyReceipt.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::destroyReceipt
* @see app/Http/Controllers/Admin/InventoryController.php:142
* @route '/admin/inventory/receipts/{receipt}'
*/
const destroyReceiptForm = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyReceipt.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::destroyReceipt
* @see app/Http/Controllers/Admin/InventoryController.php:142
* @route '/admin/inventory/receipts/{receipt}'
*/
destroyReceiptForm.delete = (args: { receipt: number | { id: number } } | [receipt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyReceipt.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyReceipt.form = destroyReceiptForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
export const itemsIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: itemsIndex.url(options),
    method: 'get',
})

itemsIndex.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/items',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
itemsIndex.url = (options?: RouteQueryOptions) => {
    return itemsIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
itemsIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: itemsIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
itemsIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: itemsIndex.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
const itemsIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
itemsIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsIndex.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsIndex
* @see app/Http/Controllers/Admin/InventoryController.php:163
* @route '/admin/inventory/items'
*/
itemsIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsIndex.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

itemsIndex.form = itemsIndexForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
export const itemsCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: itemsCreate.url(options),
    method: 'get',
})

itemsCreate.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/items/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
itemsCreate.url = (options?: RouteQueryOptions) => {
    return itemsCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
itemsCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: itemsCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
itemsCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: itemsCreate.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
const itemsCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
itemsCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsCreate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsCreate
* @see app/Http/Controllers/Admin/InventoryController.php:171
* @route '/admin/inventory/items/create'
*/
itemsCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsCreate.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

itemsCreate.form = itemsCreateForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsStore
* @see app/Http/Controllers/Admin/InventoryController.php:176
* @route '/admin/inventory/items'
*/
export const itemsStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: itemsStore.url(options),
    method: 'post',
})

itemsStore.definition = {
    methods: ["post"],
    url: '/admin/inventory/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsStore
* @see app/Http/Controllers/Admin/InventoryController.php:176
* @route '/admin/inventory/items'
*/
itemsStore.url = (options?: RouteQueryOptions) => {
    return itemsStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsStore
* @see app/Http/Controllers/Admin/InventoryController.php:176
* @route '/admin/inventory/items'
*/
itemsStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: itemsStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsStore
* @see app/Http/Controllers/Admin/InventoryController.php:176
* @route '/admin/inventory/items'
*/
const itemsStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: itemsStore.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsStore
* @see app/Http/Controllers/Admin/InventoryController.php:176
* @route '/admin/inventory/items'
*/
itemsStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: itemsStore.url(options),
    method: 'post',
})

itemsStore.form = itemsStoreForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
export const itemsEdit = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: itemsEdit.url(args, options),
    method: 'get',
})

itemsEdit.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/items/{item}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
itemsEdit.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return itemsEdit.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
itemsEdit.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: itemsEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
itemsEdit.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: itemsEdit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
const itemsEditForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
itemsEditForm.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsEdit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsEdit
* @see app/Http/Controllers/Admin/InventoryController.php:196
* @route '/admin/inventory/items/{item}/edit'
*/
itemsEditForm.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: itemsEdit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

itemsEdit.form = itemsEditForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsUpdate
* @see app/Http/Controllers/Admin/InventoryController.php:203
* @route '/admin/inventory/items/{item}'
*/
export const itemsUpdate = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: itemsUpdate.url(args, options),
    method: 'put',
})

itemsUpdate.definition = {
    methods: ["put"],
    url: '/admin/inventory/items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsUpdate
* @see app/Http/Controllers/Admin/InventoryController.php:203
* @route '/admin/inventory/items/{item}'
*/
itemsUpdate.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return itemsUpdate.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsUpdate
* @see app/Http/Controllers/Admin/InventoryController.php:203
* @route '/admin/inventory/items/{item}'
*/
itemsUpdate.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: itemsUpdate.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsUpdate
* @see app/Http/Controllers/Admin/InventoryController.php:203
* @route '/admin/inventory/items/{item}'
*/
const itemsUpdateForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: itemsUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsUpdate
* @see app/Http/Controllers/Admin/InventoryController.php:203
* @route '/admin/inventory/items/{item}'
*/
itemsUpdateForm.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: itemsUpdate.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

itemsUpdate.form = itemsUpdateForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsDestroy
* @see app/Http/Controllers/Admin/InventoryController.php:217
* @route '/admin/inventory/items/{item}'
*/
export const itemsDestroy = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: itemsDestroy.url(args, options),
    method: 'delete',
})

itemsDestroy.definition = {
    methods: ["delete"],
    url: '/admin/inventory/items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsDestroy
* @see app/Http/Controllers/Admin/InventoryController.php:217
* @route '/admin/inventory/items/{item}'
*/
itemsDestroy.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return itemsDestroy.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsDestroy
* @see app/Http/Controllers/Admin/InventoryController.php:217
* @route '/admin/inventory/items/{item}'
*/
itemsDestroy.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: itemsDestroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsDestroy
* @see app/Http/Controllers/Admin/InventoryController.php:217
* @route '/admin/inventory/items/{item}'
*/
const itemsDestroyForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: itemsDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::itemsDestroy
* @see app/Http/Controllers/Admin/InventoryController.php:217
* @route '/admin/inventory/items/{item}'
*/
itemsDestroyForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: itemsDestroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

itemsDestroy.form = itemsDestroyForm

const InventoryController = { index, create, store, receipts, destroyReceipt, itemsIndex, itemsCreate, itemsStore, itemsEdit, itemsUpdate, itemsDestroy }

export default InventoryController