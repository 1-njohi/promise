import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import receipts03856a from './receipts'
import items from './items'
/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::index
* @see app/Http/Controllers/Admin/InventoryController.php:16
* @route '/admin/inventory'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/add',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::create
* @see app/Http/Controllers/Admin/InventoryController.php:48
* @route '/admin/inventory/add'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/inventory',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::store
* @see app/Http/Controllers/Admin/InventoryController.php:60
* @route '/admin/inventory'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
export const receipts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipts.url(options),
    method: 'get',
})

receipts.definition = {
    methods: ["get","head"],
    url: '/admin/inventory/receipts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receipts.url = (options?: RouteQueryOptions) => {
    return receipts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receipts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receipts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipts.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
const receiptsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receiptsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipts.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\InventoryController::receipts
* @see app/Http/Controllers/Admin/InventoryController.php:125
* @route '/admin/inventory/receipts'
*/
receiptsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipts.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

receipts.form = receiptsForm

const inventory = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    receipts: Object.assign(receipts, receipts03856a),
    items: Object.assign(items, items),
}

export default inventory